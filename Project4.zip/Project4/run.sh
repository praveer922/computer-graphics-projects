#! /bin/sh

cd build/; ./project4 teapot.obj