#! /bin/sh

cd build/; ./project2 teapot.obj