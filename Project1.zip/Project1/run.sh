#! /bin/sh

cd build/; ./project1