#! /bin/sh

cd build/; ./project3 teapot.obj