#! /bin/sh

cd build/; ./project8 teapot_normal.png teapot_disp.png