#! /bin/sh

cd build/; ./project6 teapot.obj