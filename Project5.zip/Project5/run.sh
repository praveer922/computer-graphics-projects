#! /bin/sh

cd build/; ./project5 teapot.obj