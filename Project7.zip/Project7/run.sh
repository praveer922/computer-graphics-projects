#! /bin/sh

cd build/; ./project7 teapot.obj